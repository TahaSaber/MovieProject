package com.example.tahasaber.movieapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Taha Saber on 12/1/2016.
 */

public class TrailerAdapter extends ArrayAdapter<String> {

    public TrailerAdapter(final Context context, final ArrayList<String> trailers) {
        super(context, 0, trailers);
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.trailer_pic, parent, false);
        }

        final TextView trailerText = (TextView) convertView.findViewById(R.id.trailerItem_id);

        trailerText.setText("Trailer-> " + (position + 1));

        return convertView;
    }
}





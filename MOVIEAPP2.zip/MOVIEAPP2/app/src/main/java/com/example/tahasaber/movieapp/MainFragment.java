package com.example.tahasaber.movieapp;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 * Created by Taha Saber on 11/29/2016.
 */

public class MainFragment extends Fragment {
    List<MovieData> dataList = new ArrayList<>();
    ParseJason parsing = null;
    GridView gridView = null;
    ImageAdapter image_adapter;
    String showOpt = null;
    MovieListener movieListener;


    public MainFragment() {
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        movieListener = (MovieListener) activity;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        movieListener = (MovieListener) context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.fragment_main, container, false);
        gridView = (GridView) rootview.findViewById(R.id.content_main);
        showOpt = "popular";
        options();
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                MovieData tmpMovie = dataList.get(position);
                movieListener.setSelectedMovie(tmpMovie);

            }
        });
        return rootview;
    }

    public void setMovieListener(MovieListener movieListener){
        this.movieListener = movieListener;
    }

    public void options() {
        String url = "http://api.themoviedb.org/3/movie/" + showOpt + "?api_key=ef289fbffde829fb2f3ab30b3d3ea4c2";
        FetchJason fetch = new FetchJason();
        fetch.execute(url);
    }


    public class FetchJason extends AsyncTask<String, String, String> {


        String jsonStr = null;

        @Override
        protected String doInBackground(String... params) {

            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;

            try {
                String myUrl = params[0];
                URL url = new URL(myUrl);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    return null;
                }
                jsonStr = buffer.toString();
            } catch (IOException e) {
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {

                    }
                }
            }
            return jsonStr;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            parsing = new ParseJason(jsonStr);
            try {
                dataList = parsing.jasonParsing();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            ImageAdapter image_adapter = new ImageAdapter(getActivity(), dataList);
            gridView.setAdapter(image_adapter);
        }

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.main, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.m_popular) {
            showOpt = "popular";
            options();
        } else if (id == R.id.t_rated) {
            showOpt = "top_rated";
            options();
        } else if (id == R.id.fav_movies) {
            dataList = new ArrayList<>();
            DBHelper db = new DBHelper(getActivity());
            dataList = db.getAllMovies();
            ImageAdapter image = new ImageAdapter(getActivity(), dataList);
            gridView.setAdapter(image);

        }

        return super.onOptionsItemSelected(item);
    }

}

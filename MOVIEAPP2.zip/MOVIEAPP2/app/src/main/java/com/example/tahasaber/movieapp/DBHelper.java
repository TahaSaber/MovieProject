package com.example.tahasaber.movieapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by Taha Saber on 12/2/2016.
 */

public class DBHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "MovieDatabase";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_Movie_TABLE = "CREATE TABLE MoviesTable ( " +
                "movie_id INTEGER PRIMARY KEY , " +
                "movie_name TEXT, " +
                "description TEXT, " +
                "poster_path TEXT, " +
                "vote_avg TEXT," +
                "release_date TEXT  )";
        db.execSQL(CREATE_Movie_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS MoviesTable");
        this.onCreate(db);
    }

    private static final String TABLE_Movies = "MoviesTable";
    private static final String KEY_ID = "movie_id";
    private static final String KEY_name = "movie_name";
    private static final String KEY_description = "description";
    private static final String KEY_PosterPath = "poster_path";
    private static final String KEY_releaseDate = "release_date";
    private static final String KEY_vote_avg = "vote_avg";

    public void addMovie(MovieData movies) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_ID, movies.getMovieID());
        values.put(KEY_name, movies.getTitle());
        values.put(KEY_description, movies.getDescription());
        values.put(KEY_PosterPath, movies.getPosterPath());
        values.put(KEY_releaseDate, movies.getDate());
        values.put(KEY_vote_avg, movies.getRate());
        db.insert(TABLE_Movies, null, values);
        db.close();
    }

    public ArrayList<MovieData> getAllMovies() {
        ArrayList<MovieData> Movies = new ArrayList<>();

        String query = "SELECT  * FROM " + TABLE_Movies;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                MovieData movie = new MovieData();
                movie.setMovieID(cursor.getInt(0));
                movie.setTitle(cursor.getString(1));
                movie.setDescription(cursor.getString(2));
                movie.setPosterPath(cursor.getString(3));
                movie.setDate(cursor.getString(4));
                movie.setRate(cursor.getString(5));
                Movies.add(movie);
            } while (cursor.moveToNext());
        }
        return Movies;
    }
}
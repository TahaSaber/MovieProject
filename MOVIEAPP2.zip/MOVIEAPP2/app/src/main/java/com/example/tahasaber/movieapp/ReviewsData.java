package com.example.tahasaber.movieapp;

/**
 * Created by Taha Saber on 12/2/2016.
 */

public class ReviewsData {
    private String reviwerName;
    private String reviewBody;

    public void setReviwerName(String reviwerName) {
        this.reviwerName = reviwerName;
    }

    public void setReviewBody(String reviewBody) {
        this.reviewBody = reviewBody;
    }

    public String getReviwerName() {
        return reviwerName;
    }

    public String getReviewBody() {
        return reviewBody;
    }
}

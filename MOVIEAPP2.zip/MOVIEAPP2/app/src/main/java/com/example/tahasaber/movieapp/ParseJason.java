package com.example.tahasaber.movieapp;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

/**
 * Created by Taha Saber on 11/29/2016.
 */

public class ParseJason {

    String jason = null;

    public ParseJason(String jason) {
        this.jason = jason;
    }

    public ArrayList jasonParsing() throws ExecutionException, InterruptedException, JSONException {
        ArrayList<MovieData> movies = new ArrayList<>();
        final String MOVIE_POSTER = "poster_path";
        final String MOVIES_ID = "id";
        final String MOVIES_LIST = "results";
        final String MOVIE_DESCRIPTION = "overview";
        final String MOVIE_DATE = "release_date";
        final String MOVIE_TITLE = "original_title";
        final String MOVIE_RATE = "vote_count";
        JSONObject jasonObject = new JSONObject(jason);
        JSONArray moviesList = jasonObject.getJSONArray(MOVIES_LIST);
        MovieData movieData = null;
        for (int i = 0; i < moviesList.length(); i++) {
            JSONObject movieJason = moviesList.getJSONObject(i);
            movieData = new MovieData();
            if (movieJason.has(MOVIES_ID)) {
                movieData.setMovieID(movieJason.getInt(MOVIES_ID));
            }
            if (movieJason.has(MOVIE_POSTER)) {
                movieData.setPosterPath(movieJason.getString(MOVIE_POSTER));
            }
            if (movieJason.has(MOVIE_DESCRIPTION)) {
                movieData.setDescription(movieJason.getString(MOVIE_DESCRIPTION));
            }
            if (movieJason.has(MOVIE_DATE)) {
                movieData.setDate(movieJason.getString(MOVIE_DATE));
            }
            if (movieJason.has(MOVIE_TITLE)) {
                movieData.setTitle(movieJason.getString(MOVIE_TITLE));
            }
            if (movieJason.has(MOVIE_RATE)) {
                movieData.setRate(movieJason.getString(MOVIE_RATE));
            }
            movies.add(movieData);
        }

        return movies;
    }

}

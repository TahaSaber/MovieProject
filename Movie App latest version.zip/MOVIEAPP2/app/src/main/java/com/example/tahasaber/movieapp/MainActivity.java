package com.example.tahasaber.movieapp;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.FrameLayout;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements MovieListener {
    boolean isTwoPane;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (!isConnected()) {
            Context context = getApplicationContext();
            CharSequence text = "!Sorry, Internet Connection Lost";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();

        } else {
            FrameLayout pan2 = (FrameLayout) findViewById(R.id.pane_two);
            if (null == pan2) {
                isTwoPane = false;
            } else {
                isTwoPane = true;
            }

            if (null == savedInstanceState) {
                MainFragment mainFragment = new MainFragment();
                getFragmentManager().beginTransaction().replace(R.id.parent_view, mainFragment).commit();

            }
        }

    }

    public boolean isConnected() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    @Override
    public void setSelectedMovie(MovieData film) {
        if (isTwoPane) {
            DetailsFragment detailsFragment = new DetailsFragment();
            Bundle bundle = new Bundle();
            bundle.putSerializable("film", film);
            detailsFragment.setArguments(bundle);
            getFragmentManager().beginTransaction().replace(R.id.pane_two, detailsFragment).commit();
        } else {
            Intent intent = new Intent(this, DetailsActivity.class);
            intent.putExtra("film", film);
            startActivity(intent);
        }


    }
}

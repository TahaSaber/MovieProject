package com.example.tahasaber.movieapp;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by Taha Saber on 11/30/2016.
 */

public class DetailsFragment extends Fragment {


    TextView title;
    TextView desc;
    TextView r_date;
    TextView v_rate;
    ImageView poster;
    ListView trailers;
    Button favorite;
    MovieData movieObject;
    ListView trailerList;
    ListView reviewsList;
    public ArrayList<ReviewsData> reviews;
    public ArrayList<String> trailersArr;
    private FragmentActivity myContext;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.fragment_details, container, false);
        movieObject = (MovieData) getArguments().getSerializable("film");
        if (movieObject != null) {
            title = (TextView) rootview.findViewById(R.id.title_id);
            desc = (TextView) rootview.findViewById(R.id.desc_id);
            r_date = (TextView) rootview.findViewById(R.id.r_date);
            v_rate = (TextView) rootview.findViewById(R.id.vote_avg);
            poster = (ImageView) rootview.findViewById(R.id.image_item);
            favorite = (Button) rootview.findViewById(R.id.fav);
            trailers = (ListView) rootview.findViewById(R.id.trailers_id);
            reviewsList = (ListView) rootview.findViewById(R.id.reviews_id);
            title.setText(movieObject.getTitle());
            desc.setText(movieObject.getDescription() + "");
            r_date.setText(movieObject.getDate());
            v_rate.setText(movieObject.getRate());
            trailerList = (ListView) rootview.findViewById(R.id.trailers_id);
            reviewsList = (ListView) rootview.findViewById(R.id.reviews_id);
            Picasso.with(rootview.getContext()).load("http://image.tmdb.org/t/p/w342" + movieObject.getPosterPath()).into(poster);
            favorite.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DBHelper db = new DBHelper(getActivity());
                    db.addMovie(movieObject);
                    Toast.makeText(getActivity(), "Movie marked as favourite", Toast.LENGTH_LONG).show();

                }

            });
            boolean internetConnection = isConnected();
            if(internetConnection) {
                FTrailer fetchTrailers = new FTrailer(movieObject.getMovieID());
                fetchTrailers.execute();


                trailerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                        if (trailersArr.size() >= 1) {
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + trailersArr.get(position)));
                            startActivity(intent);
                        }

                    }

                });
                FReviews fetchReviews = new FReviews(movieObject.getMovieID());
                fetchReviews.execute();
            }
        }
        return rootview;
    }
    public boolean isConnected() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    public class FTrailer extends AsyncTask<String, Void, String> {

        int mid = 0;
        final String TRAILERS_ARRAY = "results";
        final String VIDEO_KEY = "key";

        FTrailer(int mid) {
            this.mid = mid;
        }

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            String JasonStr = null;
            JSONObject json;
            try {
                String movieID = String.valueOf(mid);
                String myuri = "http://api.themoviedb.org/3/movie/" + movieID + "/videos?api_key=ef289fbffde829fb2f3ab30b3d3ea4c2";
                URL url = new URL(myuri);
                urlConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = new BufferedInputStream(urlConnection.getInputStream());
                Scanner scan = new Scanner(inputStream).useDelimiter("\\A");
                String result = scan.hasNext() ? scan.next() : "";

                json = new JSONObject(result);
            } catch (IOException e) {
                return null;
            } catch (JSONException e) {
                return null;
            }
            JasonStr = json.toString();
            return JasonStr;
        }

        @Override
        protected void onPostExecute(String str) {
            super.onPostExecute(str);
            try {
                JSONObject result = new JSONObject(str);
                JSONArray trailersList = result.getJSONArray(TRAILERS_ARRAY);
                trailersArr = new ArrayList<String>();

                for (int i = 0; i < trailersList.length(); i++) {
                    JSONObject trailer = trailersList.getJSONObject(i);
                    if (trailer.has(VIDEO_KEY))
                        trailersArr.add(trailer.getString(VIDEO_KEY));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            if (trailersArr.size() >= 1) {
                TrailerAdapter trailerAdapter = new TrailerAdapter(getActivity(), trailersArr);
                trailerList.setAdapter(trailerAdapter);
            }


        }


    }

    public class FReviews extends AsyncTask<String, Void, String> {

        int mid = 0;
        public ArrayList<ReviewsData> reviews;
        final String REVIEWS = "results";
        final String REVIEWER = "author";
        final String REVIEW_BODY = "content";
        ReviewsData reviewsData = null;

        FReviews(int mid) {
            this.mid = mid;
        }

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            String JasonStr = null;
            JSONObject json;
            try {
                String movieID = String.valueOf(mid);
                String myuri = "http://api.themoviedb.org/3/movie/" + movieID + "/reviews?api_key=ef289fbffde829fb2f3ab30b3d3ea4c2";
                URL url = new URL(myuri);
                urlConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = new BufferedInputStream(urlConnection.getInputStream());
                Scanner scan = new Scanner(inputStream).useDelimiter("\\A");
                String result = scan.hasNext() ? scan.next() : "";

                json = new JSONObject(result);
            } catch (IOException e) {
                return null;
            } catch (JSONException e) {
                return null;
            }
            JasonStr = json.toString();
            return JasonStr;
        }

        @Override
        protected void onPostExecute(String str) {
            super.onPostExecute(str);
            try {
                JSONObject result = new JSONObject(str);
                JSONArray reviewsArr = result.getJSONArray(REVIEWS);
                reviewsData = new ReviewsData();
                reviews = new ArrayList<>();
                for (int i = 0; i < reviewsArr.length(); i++) {
                    JSONObject reviewObj = reviewsArr.getJSONObject(i);
                    if (reviewObj.has(REVIEW_BODY) && reviewObj.has(REVIEWER)) {
                        reviewsData.setReviwerName(reviewObj.getString(REVIEWER));
                        reviewsData.setReviewBody(reviewObj.getString(REVIEW_BODY));
                    }
                    reviews.add(reviewsData);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

            if (reviews.size() >= 1) {
                ReviewAdapter reviewAdapter = new ReviewAdapter(getActivity(), reviews);
                reviewsList.setAdapter(reviewAdapter);
            }

        }
    }
}

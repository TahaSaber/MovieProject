package com.example.tahasaber.movieapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        Bundle extras = new Bundle();
        extras.putSerializable("film", getIntent().getSerializableExtra("film"));
        if (null == savedInstanceState) {
            DetailsFragment mDetailsFragment = new DetailsFragment();
            mDetailsFragment.setArguments(extras);
            getFragmentManager().beginTransaction().add(R.id.details_view, mDetailsFragment).commit();
        }


    }
}

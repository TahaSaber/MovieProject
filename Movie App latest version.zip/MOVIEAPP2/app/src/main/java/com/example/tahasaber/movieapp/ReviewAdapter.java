package com.example.tahasaber.movieapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Taha Saber on 12/1/2016.
 */


public class ReviewAdapter extends ArrayAdapter<ReviewsData> {

    ArrayList<ReviewsData> Reviews;
    public ReviewAdapter(final Context context, final ArrayList<ReviewsData> reviewsDatas) {
        super(context, 0, reviewsDatas);
        Reviews = reviewsDatas;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.review, parent, false);
        }

        final TextView reviewBody = (TextView) convertView.findViewById(R.id.desc_id);
        final TextView reviewer = (TextView) convertView.findViewById(R.id.reviewer_id);

        reviewer.setText(Reviews.get(position).getReviwerName());
        reviewBody .setText(Reviews.get(position).getReviewBody());

        return convertView;
    }
}






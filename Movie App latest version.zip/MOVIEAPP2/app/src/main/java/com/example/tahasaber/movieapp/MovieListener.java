package com.example.tahasaber.movieapp;

/**
 * Created by Taha Saber on 12/3/2016.
 */

public interface MovieListener {
    public void setSelectedMovie(MovieData name);
}

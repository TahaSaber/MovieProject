package com.example.tahasaber.movieapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Taha Saber on 11/27/2016.
 */

public class ImageAdapter extends BaseAdapter {
    private Context mContext;
    private List<MovieData> mThumbIds;

    public ImageAdapter(Context mContext, List<MovieData> mThumbIds) {
        this.mContext = mContext;
        this.mThumbIds = mThumbIds;
    }
    public ImageAdapter(Context c) {
        mContext = c;
    }

    public int getCount() {
        return mThumbIds.size();
    }

    public MovieData getItem(int position) {
        return mThumbIds.get(position);
    }

    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null) {
            convertView = inflater.from(mContext).inflate(R.layout.grid_item, null);

        }
        imageView = (ImageView) convertView.findViewById(R.id.image_item);
        Picasso.with(mContext).load("http://image.tmdb.org/t/p/w342" + getItem(position).getPosterPath()).into(imageView);
        return convertView;
    }
}
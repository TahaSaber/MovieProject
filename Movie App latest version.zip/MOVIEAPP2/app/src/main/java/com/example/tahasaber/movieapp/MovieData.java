package com.example.tahasaber.movieapp;

import java.io.Serializable;

/**
 * Created by Taha Saber on 11/29/2016.
 */

public class MovieData implements Serializable {
    private String posterPath;
    private int movieID;
    private String title;
    private String description;
    private String date;
    private String rate;


    public void setPosterPath(String s) {
        posterPath = s;
    }

    public void setMovieID(int s) {
        movieID = s;
    }

    public String getPosterPath() {
        return posterPath;
    }

    public int getMovieID() {
        return movieID;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getDate() {
        return date;
    }

    public String getRate() {
        return rate;
    }


}
